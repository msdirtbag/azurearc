# LogMaster
# 0.0.1

using namespace System.Net
using namespace Microsoft.WindowsAzure.Storage
using namespace Microsoft.WindowsAzure.Storage.Blob

# Input bindings are passed in via param block.
param($Timer)

# Import necessary modules
Import-Module -Name Az -Force
Import-Module -Name ExchangeOnlineManagement -Force

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# Get environment variables
$connectionString = [System.Environment]::GetEnvironmentVariable('StorageConnectionString', 'Process')
$umicid = [System.Environment]::GetEnvironmentVariable('AZURE_CLIENT_ID', 'Process')
$umitenant = [System.Environment]::GetEnvironmentVariable('TENANT_DOMAIN', 'Process')

# Connect to Exchange Online
Connect-ExchangeOnline -ManagedIdentity -Organization $umitenant -ManagedIdentityAccountId $umicid

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# Get the current time
$endDate = Get-Date

# Set the start date to one hour before the end date
$startDate = $endDate.AddHours(-1)

# Format the dates
$endDate = $endDate.ToString("yyyy-MM-dd HH:mm:ss")
$startDate = $startDate.ToString("yyyy-MM-dd HH:mm:ss")

# Define maximum number of retries
$maxRetries = 3
$retryCount = 0

# Create a storage context
$storageContext = New-AzStorageContext -ConnectionString $connectionString

# Get a reference to the blob container
$container = Get-AzStorageContainer -Name "mailitems" -Context $storageContext

# Define the blob name
$timestamp = Get-Date -Format "yyyyMMddHHmmss"
$blobName = "sessions_$timestamp.json"

# Create a temporary file
$tempFile = New-TemporaryFile

# Write an information log with the current time.
Write-Verbose "PowerShell timer trigger function ran! TIME: $currentUTCtime"

# Try to retrieve and upload audit logs
for ($retryCount = 0; $retryCount -lt $maxRetries; $retryCount++) {
    try {
        Write-Verbose "Attempt number: $($retryCount + 1)"
        Write-Verbose "Attempting to search Unified Audit Log..."
        $auditLogs = Search-UnifiedAuditLog -StartDate $startDate -EndDate $endDate -SessionCommand "ReturnLargeSet" -ResultSize 5000 -Operations "MailItemsAccessed" -Formatted | ForEach-Object { $_ | ConvertTo-Json }
        if ($auditLogs) {
            Write-Verbose "Audit logs successfully retrieved."
            # Check if the content is not null or empty
            if (![string]::IsNullOrEmpty($auditLogs)) {
                # Write the audit logs JSON to the temporary file
                $auditLogs | Out-File -FilePath $tempFile.FullName

                # Upload the data from the variable to the blob
                Write-Verbose "Uploading content to blob..."
                $result = Set-AzStorageBlobContent -Blob $blobName -Container $container.Name -Context $storageContext -File $tempFile.FullName -Force

                # Delete the temporary file
                Remove-Item -Path $tempFile.FullName
            } else {
                throw "Audit logs JSON is null or empty."
            }
        } else {
            Write-Verbose "No audit logs retrieved."
            continue
        }
    }
    catch {
        Write-Error "Attempt $retryCount failed with error: $($_.Exception.Message). HTTP status code: $($result.Context.HttpResponse.StatusCode)"
        Write-Verbose "Retrying..."
        Start-Sleep -Seconds (2 * $retryCount)
    }
}

# Write an information log with the current time.
Write-Verbose "PowerShell timer trigger function ran! TIME: $currentUTCtime"